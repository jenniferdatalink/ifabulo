<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
//setting up path so we can use it in entire file 
//if your component folder have upper and lower case characters please use same here.
define('__OSSN_PACKAGE_MANAGER__', ossn_route()->com . 'PackageManager/');

ossn_register_languages('en', $en);


//this function is use to initilize ossn
function ossn_pacakge_manager() {
  /**
  * Lets add our css to ossn default css file,
  * Lets create css directory in your component directory here our
  * directory name is HelloWorld so lets create new directory name css in HelloWorld
  * directory after that create a file name helloworld.php in it and add css
  * ossn.default is name of css.
  * use following code to add css in ossn default css file
  */
   ossn_extend_view('css/ossn.default', 'css/packagemanager');
   
   
  /**
  * For javascript you can do same thing , but instead of css you need to use js see code below:
  */   
   ossn_extend_view('js/opensource.socialnetwork', 'js/packagemanager');
  
  /**
  * Sometime you can't extned other css or js file as it creates conflicts in css or js,
  * so for that purpose you need to create seprate js or css file.
  * Now lets create a new directory called standalone in css directory 
  * create a file called helloworld.php in your standalone directory add your css code in that file.
  * To create seprate css link in header you can use following code.
  */
   //this will just tell system that new css file for header is available
   ossn_new_css('package.manager', 'css/standalone/packagemanager');
   
   //now tell system to load file in header, here the first argument in function must be same as you 
   //used in ossn_new_css(<argument>) 
   ossn_load_css('package.manager');
   
   //lets create a new page called hello and print hello for that we need to use following code.
   ossn_register_page('package', 'package_manager_page');

    ossn_register_admin_sidemenu('admin:packages', 'admin:packages', ossn_site_url('administrator/packages'), ossn_print('admin:sidemenu:packagemanager'));
    ossn_register_admin_sidemenu('admin:add:package', 'admin:add:package', ossn_site_url('administrator/addpackage'), ossn_print('admin:sidemenu:packagemanager'));
    ossn_register_admin_sidemenu('admin:packages:unvalidated', 'admin:packages:unvalidated', ossn_site_url('administrator/unvalidated_packages'), ossn_print('admin:sidemenu:packagemanager'));

}
//page function that is create by ossn_register_page('hello', 'ossn_hello_page');
//the code below is use to print hello world in page.
// vist http://mysite.com/hello to view page
function ossn_package_manager(){
  echo "Hello Package Manager";
}
//this line is used to register initliize function to ossn system
ossn_register_callback('ossn', 'init', 'ossn_package_manager');
