.package-manager-standalone {
  //css goes here
}