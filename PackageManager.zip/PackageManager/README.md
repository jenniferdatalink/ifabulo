PackageManager
==========

Package Manager Component, that allows for the creation of different member packages a User can sign up to.