<?php
/**
 * Created by PhpStorm.
 * User: jenniferjoseph
 * Date: 2/04/2017
 * Time: 5:08 PM
 */

$en = array(
    'admin:sidemenu:packagemanager' => 'Package Manager',
);