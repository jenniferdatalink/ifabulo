<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
define('__USER_MEMORY_ALLOCATION__', ossn_route()->com . 'usermemoryallocation/');
/**
 * Initialize the component
 *
 * @return void
 */
function user_memory_allocation_init(){
    ossn_add_hook('wall', 'templates:item', 'ossn_embed_replacer', 100);
    ossn_add_hook('comment:view', 'template:params', 'ossn_replace_in_comments', 100);
    ossn_extend_view('css/ossn.default', 'css/usermemoryallocation');
    ossn_extend_view('js/opensource.socialnetwork', 'js/usermemoryallocation');

}

/**
 *
 *
 * @params string $hook Name of hook is user
 * @params string $type Type of hook is signup fields
 *
 * @return array
 */
function user_memory_allocation($hook, $type, $return, $params){
    $postSize = new UserMemoryAllocation();
    $postSize = $postSize->bytesInString($params['post']);

}

ossn_register_callback('ossn', 'init', 'user_memory_allocation_init');


/**
 * Each time a POST is saved
 * The size of the post is calculates and then saved
 *
 * This keeps a log of all posts.
 *
 * On the User Profile screen, these are all calculated to get the allocation for the user
 *
 * We also need another process (daily?) that checks the Users total against their allocation and marks posts as
 * 'to be deleted' if over allocation
 *
 * We also need another process that removes these after 30 (?) days
 *
 *
 * Also need to think about what happens when a user, because they have gone over their allocation , decides to upgrate
 * their package. In this case we need to mark any 'deleted' posts as undeleted.
 *
 * Also need to think about user notification.
 */
