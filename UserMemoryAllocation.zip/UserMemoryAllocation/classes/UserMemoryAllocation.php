<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright 2014-2017 SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
class UserMemoryAllocation extends OssnDatabase {

    /**
     * Initialize the objects.
     *
     * @return void
     */
    public function initAttributes() {
        $this->OssnDatabase   = new OssnDatabase;
        $this->OssnAnnotation = new OssnAnnotation;
        $this->data = new stdClass;



    }

    private function _createUserMemoryAllocationTableIfItDoesNotExist() {
        $qry = "CREATE TABLE IF NOT EXISTS user_memory_allocation (
                      id INT KEY NOT NULL AUTO_INCREMENT, 
                      userid TEXT, 
                      postid INT, 
                      memory INT, 
                      type TEXT, 
                      markedfordeletion INT(1)
                    )";

        $db = new OssnDatabase;
        $db->statement($qry);
        $db->execute();

    }

    /**
     * Count the number of bytes of a given string.
     * Input string is expected to be ASCII or UTF-8 encoded.
     *
     * @see http://www.hashbangcode.com/blog/work-out-size-bytes-php-string
     * @see http://www.cl.cam.ac.uk/~mgk25/unicode.html#utf-8   for information on UTF-8.
     *
     * @param string $str The string to compute number of bytes
     *
     * @return int $noOfBytes The length in bytes of the given string.
     */
    public function bytesInString($str){
        // STRINGS ARE EXPECTED TO BE IN ASCII OR UTF-8 FORMAT

        // Number of characters in string
        $strlen_var = strlen($str);

        // string bytes counter
        $noOfBytes = 0;

        /*
        * Iterate over every character in the string,
        * escaping with a slash or encoding to UTF-8 where necessary
        */
        for($c = 0; $c < $strlen_var; ++$c){
            $ord_var_c = ord($str{$c});
            switch(true){
                case(($ord_var_c >= 0x20) && ($ord_var_c <= 0x7F)):
                    // characters U-00000000 - U-0000007F (same as ASCII)
                    $noOfBytes++;
                    break;
                case(($ord_var_c & 0xE0) == 0xC0):
                    // characters U-00000080 - U-000007FF, mask 110XXXXX
                    $noOfBytes+=2;
                    break;
                case(($ord_var_c & 0xF0) == 0xE0):
                    // characters U-00000800 - U-0000FFFF, mask 1110XXXX
                    $noOfBytes+=3;
                    break;
                case(($ord_var_c & 0xF8) == 0xF0):
                    // characters U-00010000 - U-001FFFFF, mask 11110XXX
                    $noOfBytes+=4;
                    break;
                case(($ord_var_c & 0xFC) == 0xF8):
                    // characters U-00200000 - U-03FFFFFF, mask 111110XX
                    $noOfBytes+=5;
                    break;
                case(($ord_var_c & 0xFE) == 0xFC):
                    // characters U-04000000 - U-7FFFFFFF, mask 1111110X
                    $noOfBytes+=6;
                    break;
                default:
                    $noOfBytes++;
            };
        };
        return $noOfBytes;
    }

    /**
     * Each time a POST is saved
     * The size of the post is calculates and then saved
     *
     * This keeps a log of all posts.
     *
     * On the User Profile screen, these are all calculated to get the allocation for the user
     *
     * We also need another process (daily?) that checks the Users total against their allocation and marks posts as
     * 'to be deleted' if over allocation
     *
     * We also need another process that removes these after 30 (?) days
     *
     *
     * Also need to think about what happens when a user, because they have gone over their allocation , decides to upgrate
     * their package. In this case we need to mark any 'deleted' posts as undeleted.
     *
     * Also need to think about user notification.
     */

}