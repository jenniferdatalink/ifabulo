UserMemoryUsage
==========

User Memory Usage Component, allows the user to view and manage their current memory usage.