$(document).ready(function(){
	//simple js code
});
