.user-memory-usage-manager-css {
 //css goes here
}
