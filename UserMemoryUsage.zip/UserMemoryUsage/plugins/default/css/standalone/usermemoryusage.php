.user-memory-usage-manager-standalone {
  //css goes here
}